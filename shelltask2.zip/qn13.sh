#delete allempty text files
read -p "Enter the directory path: " dir
cd "$dir" || { echo "Directory not found"; exit 1; }
echo "Deleting all empty text files in $dir:"
for file in *.txt; do
    if [[ -f $file && ! -s $file ]]
    then
        rm "$file"
        echo "Deleted empty file: $file"
    else
        echo "No empty text files found."
    fi
done
echo "Deletion process completed."


