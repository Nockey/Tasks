read -p "Enter the list of names:" l
for i in $l
do
  echo Welcome $i
done
