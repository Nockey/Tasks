#display contents of a file line by line with line numbers
read -p "Enter filename: " fname
if [[ -f $fname ]]; then
	echo "Contents of '$fname':"
	nl -ba "$fname"
else
	echo "File '$fname' does not exist."
fi