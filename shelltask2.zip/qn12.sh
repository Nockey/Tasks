#print multiplication table of a number
read -p "Enter a number: " n
echo "Multiplication table for $n:"
for ((i=1; i<=10; i++))
do
    echo "$n x $i = $((n * i))"         
done
echo "End of multiplication table for $n."