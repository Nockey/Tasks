#display current time every 5 seconds until interrupted
while true; do
    clear
    echo $(date)
    sleep 5
done
# Note: This script will run indefinitely until manually stopped (e.g., with Ctrl+C).
