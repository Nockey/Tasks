#script to count words in a file
read -p "Enter filename: " fname
if [[ -f $fname ]]; then    ]
    word_count=$(wc -w < "$fname")
    echo "The file '$fname' contains $word_count words."
else
    echo "File '$fname' does not exist."
fi