#save text file with current date
read -p "Enter the text to save: " text
current_date=$(date +%Y-%m-%d)
filename="textfile_$current_date.txt"
echo "$text" > "$filename"
echo "Text saved to $filename"