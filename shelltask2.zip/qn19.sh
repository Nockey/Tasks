#reverse each line in a file
read -p "Enter file name:" fname
if [[ -f $fname ]]; then
    echo "Reversed lines in '$fname':"
    while IFS= read -r line; do
        len=${#line}
        rev_line=""
        for (( i=$len-1; i>=0; i-- )); do
            rev_line="$rev_line${line:$i:1}"
        done
        echo "$rev_line"
    done < "$fname"
else
    echo "File '$fname' does not exist."
fi