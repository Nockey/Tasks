#move .log files to logs folder
read -p "Enter a directory: " dir
mkdir logs
for i in *.log; do
	mv "$i" "logs"
done
