#backup a file by appending .bak to its name
read -p "Enter filename: " fname
if [ -f "$fname" ]; then    
    cp "$fname" "${fname}.bak"
    echo "Backup of '$fname' created as '${fname}.bak'."
else
    echo "File '$fname' does not exist."
fi