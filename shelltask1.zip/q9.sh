#qn9
#basic calculator
read -p "Enter the expression (e.g., 5 + 3): " x op y
case $op in
    +) result=$(($x+$y));;
    -) result=$(($x-$y));;
    \*) result=$(("$x*$y"));;
    /) if [ $y -eq 0 ]
        then
            echo "Division by zero is not allowed." 
        else
            result=$(("$x/$y"))
     fi
     ;;
    %) if [ $y -eq 0 ]
        then
            echo "Division by zero is not allowed." 
        else
            result=$(("$x%$y"))
     fi
     ;;
    *) echo "Invalid operator"; 
esac  
echo "Result: $result"
