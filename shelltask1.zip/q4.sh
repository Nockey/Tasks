#qn4
# Check if a directory exists and is writable
read -p "Enter the directory path: " dir
if [ -d "$dir" ]
then
    if [ -w "$dir" ]
    then
        echo "Directory exists and is writable"
    else
        echo "Directory exists but is not writable"
    fi
else
    echo "Directory does not exist"
fi
