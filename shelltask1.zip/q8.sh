#qn8
#check if the number is palindrome
read -p "Enter a number: " num
n1=$num
temp=0
while [ $num -gt 0 ]
do
  rem=$((num % 10))
  temp=$((temp * 10 + rem))
  num=$((num / 10))
done
if [ $n1 -eq $temp ]
then
  echo "$n1 is a palindrome"
else
  echo "$n1 is not a palindrome"
fi
