
#qn3
#check if the date is valid
read -n 5 -p "Enter month and day (DD-MM): " md
m=${md:3:2}
d=${md:0:2}
valid=false
if [ "$d" -gt 0 ] && [ "$d" -le 31 ] && [ "$m" -ge 1 ] && [ "$m" -le 12 ]
then    
    case $m in
        01|03|05|07|08|10|12) 
        if [ "$d" -le 31 ]; then
            valid=true
        fi ;;     
        04|06|09|11) 
        if [ "$d" -le 30 ]; then
            valid=true
        fi ;;
        02)
        if [ "$d" -le 28 ]; then
            valid=true
        fi ;;    
        *) 
        ;;
    esac; 
fi
if [ "$valid" = true ]; then
    echo "Valid date"
else
    echo "Invalid date"
fi
