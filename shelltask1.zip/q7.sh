#qn7
#grade calculator
read  -p "Enter your marks: " marks
if [ $marks -ge 0 ] && [ $marks -le 100 ]; then
    if [ $marks -ge 90 ] 
    then
        echo "A grade."
    elif [ $marks -ge 75 ]
    then
        echo "B grade."
    elif [ $marks -ge 60 ]
    then
        echo "C grade."
    else
        echo "Fail"
    fi
else
    echo "Marks should be between 0 and 100"
fi
