
#qn1
# Check if a year is a leap year
read -p "Enter a year:" year
if [ $year -lt 0 ]
then
  echo "Year cannot be negative."
elif [ $((year % 4)) -eq 0 ] && { [ $((year % 100)) -ne 0 ] || [ $((year % 400)) -eq 0 ];}
then
  echo "It is a Leap year"
else
  echo "It is not a Leap year"
fi
