#qn6
# simple login validation
user="sudhan"
passwd="Sudhan@123"
read -p "Enter username: " ipuser
read -sp "Enter password: " ippasswd
if [ "$ipuser" = "$user" ] && [ "$ippasswd" = "$passwd" ]
then
  echo -e "\nLogin successful"
else
  echo -e "Access denied"
fi