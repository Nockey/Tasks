#qn2
# Find the smallest of three numbers
read -p "Enter number 1: " a
read -p "Enter number 2: " b
read -p "Enter number 3: " c
if [ $a -lt $b ] && [ $a -lt $c ]
then
  echo "$a is the smallest number"
elif [ $b -lt $a ] && [ $b -lt $c ]
then
  echo "$b is the smallest number"
else
  echo "$c is the smallest number"
fi
