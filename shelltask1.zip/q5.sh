#qn5
#check character type
read -p "Enter a character: " char
if [[ $char =~ ^[a-zA-Z]$ ]]
then
  echo "$char is an alphabet"
elif [[ $char =~ ^[0-9]$ ]]
then
  echo "$char is a digit"
else
  echo "$char is a special character"
fi
