#qn10   
#check if a file has content
read -p "Enter the filename to check: " fname
if [ -s $fname ]
then
  echo "File has content"
else
  echo "File is empty"
fi